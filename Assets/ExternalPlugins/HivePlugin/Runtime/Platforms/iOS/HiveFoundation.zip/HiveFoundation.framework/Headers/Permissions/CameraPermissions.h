//
//  CameraPermissions.h
//  HiveFoundation
//
//  Created by Bartt on 27/08/2018.
//  Copyright © 2018 Hive Community. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/Permissions/Permissions.h>

@interface CameraPermissions : NSObject
+ (void)request:(hivePermissionStatusHandler _Nonnull)callback;

@end
