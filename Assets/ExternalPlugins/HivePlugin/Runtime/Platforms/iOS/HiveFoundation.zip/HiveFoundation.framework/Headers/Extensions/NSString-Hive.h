//
//  NSString-Hive.h
//  HiveFoundation
//
//  Created by Bartt on 13/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef const char* UnityString;


@interface NSString (Hive)
+ (nullable instancetype)stringWithUnityStringOrNull:(UnityString _Nullable)str;
+ (nonnull instancetype)stringWithUnityStringOrEmpty:(UnityString _Nullable)str;

- (nonnull UnityString)unityString;
- (nonnull NSString *)percentEncodedUrlString;
@end


//------------------------------------------------------------------------------------
#pragma mark - Export C

// Converts NSString to a Unity string. Returns null if source string is nil.
NS_INLINE UnityString _Nullable hiveNSStringToUnityStringOrNull(NSString* _Nullable str)
{
    return [str UTF8String];
}

// Converts NSString to a Unity string. Returns an empty string if source string is nil.
NS_INLINE UnityString _Nonnull hiveNSStringToUnityStringOrEmpty(NSString* _Nullable str)
{
    return str != nil ? [str UTF8String] : "";
}

// Converts Unity string to a NSString. Returns nill if source string is null.
NS_INLINE NSString* _Nullable hiveUnityStringToNSStringOrNull(UnityString _Nullable str)
{
    return str != NULL ? [NSString stringWithUTF8String:str] : nil;
}

// Converts Unity string to NSString. Returns an empty string if source string is null.
NS_INLINE NSString* _Nonnull hiveUnityStringToNSStringOrEmpty(UnityString _Nullable str)
{
    return str != NULL ? [NSString stringWithUTF8String:str] : @"";
}

// Duplicates Unity string (needed for return string from native code to Unity plugin)
FOUNDATION_EXPORT UnityString _Nullable hiveDuplicateUnityString(UnityString _Nullable str);

// Use these macroses to pass string value from native plugin to Unity
#define hiveMarshalAsNSString(_x_)     hiveDuplicateUnityString(hiveNSStringToUnityStringOrNull(_x_))
#define hiveMarshalAsUnityString(_x_)  hiveDuplicateUnityString(_x_)

// Returns a percent-escaped string (for url)
NS_INLINE NSString* _Nullable hiveNSStringToUrlEncodedString(NSString* _Nullable string)
{
    return [string stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet characterSetWithCharactersInString:@"!*'();:@&=+$,/?%#[]"]];
}
