//
//  Callbacks.h
//  HiveFoundation
//
//  Created by Bartt on 13/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <HiveFoundation/Extensions/NSString-Hive.h>

#define DECLARE_CALLBACK(typeName, ...) \
typedef struct \
{ \
    void* _Nullable ptr; \
    void (* _Nullable action)(void* _Nullable ptr, __VA_ARGS__); \
} typeName;

typedef struct
{
    void* _Nullable ptr;
    void (* _Nullable action)(void* _Nullable ptr);
} UnityVoidCallback;

DECLARE_CALLBACK(UnityBooleanCallback, bool arg1)
DECLARE_CALLBACK(UnityInt32Callback, int arg1)
DECLARE_CALLBACK(UnityStringCallback, UnityString _Nullable arg1)
DECLARE_CALLBACK(UnityJsonCallback, UnityString _Nullable arg1)

#undef DECLARE_CALLBACK
