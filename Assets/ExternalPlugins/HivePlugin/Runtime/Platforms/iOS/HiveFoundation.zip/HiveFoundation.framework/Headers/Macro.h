//
//  Macro.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#pragma once

#import <Foundation/Foundation.h>

// Calling declaration of exported methods
#define UNITY_EXPORT FOUNDATION_EXPORT

//------------------------------------------------------------------------------------------------------------------------
// ARC/Non-ARC guard
//------------------------------------------------------------------------------------------------------------------------
#if __has_feature(objc_arc)
#define arc_retain(obj) (obj)
#define arc_autorelease(obj) (obj)
#define arc_release(obj) (obj)
#define arc_dealloc(obj) {}
#define arc_bridge(type, obj) ((__bridge type)(obj))
#define arc_bridge_retain(type, obj) ((__bridge_retained type)(obj))
#define arc_bridge_release(type, obj) ((__bridge_transfer type)(obj))
#else
#define arc_retain(obj) [obj retain]
#define arc_autorelease(obj) [obj autorelease]
#define arc_release(obj) [obj release]
#define arc_dealloc(obj) [obj dealloc]
#define arc_bridge(type, obj) ((type)(obj))
#define arc_bridge_retain(type, obj) ([(type)(obj) retain])
#define arc_bridge_release(type, obj) ([(type)(obj) release])
#endif

//------------------------------------------------------------------------------------------------------------------------
// iOS Version comparers
//------------------------------------------------------------------------------------------------------------------------
#define IOS_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define IOS_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define IOS_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define IOS_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define IOS_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

//------------------------------------------------------------------------------------------------------------------------
// Logging
//------------------------------------------------------------------------------------------------------------------------
#define _hiveLOG_SELECTOR_MSG(s, ...) \
    NSLog(@"DBG: in [%@ %@]: %@", \
    NSStringFromClass([self class]), \
    NSStringFromSelector(_cmd), \
    [NSString stringWithFormat:(s), ##__VA_ARGS__])

#define _hiveLOG(s, ...) \
    NSLog(@"DBG: %@", [NSString stringWithFormat:(s), ##__VA_ARGS__])


#define hiveLOG_SELECTOR               _hiveLOG(@"selector invoked: %@ %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd))
#define hiveLOG(...)                   _hiveLOG(__VA_ARGS__)
#define hiveLOG_SELECTOR_MSG(...)      _hiveLOG_SELECTOR_MSG(__VA_ARGS__)

// Debug mode logging
#ifdef DEBUG

#define hiveDBG_LOG_SELECTOR           hiveLOG_SELECTOR
#define hiveDBG_LOG(...)               _hiveLOG(__VA_ARGS__)
#define hiveDBG_LOG_SELECTOR_MSG(...)  _hiveLOG_SELECTOR_MSG(__VA_ARGS__)

// ifdef DEBUG
#else

#define hiveDBG_LOGSELECTOR {}
#define hiveDBG_LOG(...) {}
#define hiveDBG_LOGSELECTOR_MSG(...) {}

// ifdef DEBUG
#endif

#undef _hiveLOG_SELECTOR_MSG
#undef _hiveLOG
