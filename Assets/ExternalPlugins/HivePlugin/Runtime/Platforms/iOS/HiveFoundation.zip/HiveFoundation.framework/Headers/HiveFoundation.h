//
//  HiveFoundation.h
//  HiveFoundation
//
//  Created by Bartt on 28/05/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

// Common
#import <HiveFoundation/Macro.h>
#import <HiveFoundation/Callbacks.h>

// Extensions
#import <HiveFoundation/Extensions/NSString-Hive.h>
#import <HiveFoundation/Extensions/NSDictionary-Hive.h>
#import <HiveFoundation/Extensions/NSDate-Hive.h>

// Logging
#import <HiveFoundation/Logging/Logger.h>
#import <HiveFoundation/Logging/StdoutLogger.h>

// AppHost
#import <HiveFoundation/AppHost/AppHost.h>
#import <HiveFoundation/AppHost/AppControllerListener.h>
#import <HiveFoundation/AppHost/AppControllerDispatcher.h>

// Localization
#import <HiveFoundation/Localization/HiveLocale.h>
#import <HiveFoundation/Localization/LocalizedResources.h>

// Permissions service
#import <HiveFoundation/Permissions/Permissions.h>
#import <HiveFoundation/Permissions/CameraPermissions.h>
#import <HiveFoundation/Permissions/GalleryPermissions.h>
#import <HiveFoundation/Permissions/LocalNotificationsPermissions.h>
