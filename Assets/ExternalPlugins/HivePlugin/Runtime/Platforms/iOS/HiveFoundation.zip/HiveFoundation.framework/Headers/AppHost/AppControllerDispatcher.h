//
//  AppControllerDispatcher.h
//  HiveFoundation
//
//  Created by Bartt on 28/05/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/AppHost/AppControllerListener.h>

@interface AppControllerDispatcher : NSObject

- (nonnull instancetype)init;

- (void)addListener:(nonnull id<AppControllerListener>)listener;
- (void)removeListener:(nonnull id<AppControllerListener>)listener;

@end
