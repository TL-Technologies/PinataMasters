//
//  NSDate-Hive.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Hive)
+ (nonnull instancetype)dateWithUnixTimestamp:(uint64_t)ts;
- (uint64_t)unixTimestamp;
- (nonnull NSString *)utcString;

@end
