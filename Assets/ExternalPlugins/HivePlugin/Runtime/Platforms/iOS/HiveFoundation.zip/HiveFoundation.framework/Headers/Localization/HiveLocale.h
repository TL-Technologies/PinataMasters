//
//  HiveLocale.h
//  HiveFoundation
//
//  Created by Bartt on 17/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>

extern const NSNotificationName _Nonnull hiveLocaleNotify_LocaleChanged;


@interface HiveLocale : NSObject

+ (nonnull NSString *)currentLocale;
+ (void)setCurrentLocale:(nonnull NSString *)localeIdentifier;

+ (void)addObserver:(nonnull id)observer selector:(nonnull SEL)selector object:(nullable id)object;
+ (void)removeObserver:(nonnull id)observer object:(nullable id)object;

@end
