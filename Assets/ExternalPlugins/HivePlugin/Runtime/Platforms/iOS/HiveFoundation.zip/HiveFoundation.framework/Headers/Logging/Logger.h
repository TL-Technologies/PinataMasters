//
//  Logger.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(int, HiveLogLevel)
{
    HiveLogLevelNone    = 0,
    HiveLogLevelError   = 1,
    HiveLogLevelWarning = 2,
    HiveLogLevelInfo    = 3,
    HiveLogLevelDebug   = 4,
};

typedef NS_ENUM(int, HiveLogLevelMask)
{
    HiveLogLevelMaskNone     = 0,
    HiveLogLevelMaskErrors   = 1 << HiveLogLevelError,
    HiveLogLevelMaskWarnings = 1 << HiveLogLevelWarning,
    HiveLogLevelMaskInfo     = 1 << HiveLogLevelInfo,
    HiveLogLevelMaskDebug    = 1 << HiveLogLevelDebug,

    HiveLogLevelMaskAll =
        HiveLogLevelMaskErrors |
        HiveLogLevelMaskWarnings |
        HiveLogLevelMaskInfo |
        HiveLogLevelMaskDebug
};


@protocol Logger <NSObject>
@property (nonatomic) HiveLogLevelMask levelMask;

- (BOOL)isEnabled:(HiveLogLevel)level;

- (void)e:(nullable NSString *)format, ...;
- (void)w:(nullable NSString *)format, ...;
- (void)i:(nullable NSString *)format, ...;
- (void)d:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag e:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag w:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag i:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag d:(nullable NSString *)format, ...;

@end


NS_INLINE BOOL hiveLogLevelMaskHas(HiveLogLevelMask levelMask, HiveLogLevel level)
{
    return
        level != HiveLogLevelNone && // NO, if level == none
        (levelMask & (1 << level)) != 0;
}
