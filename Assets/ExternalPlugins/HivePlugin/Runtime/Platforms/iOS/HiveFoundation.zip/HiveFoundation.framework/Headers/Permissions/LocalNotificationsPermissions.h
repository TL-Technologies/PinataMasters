//
//  LocalNotificationsPermissions.h
//  HiveFoundation
//
//  Created by Bartt on 24/08/2018.
//  Copyright © 2018 Hive Community. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/Permissions/Permissions.h>
#import <HiveFoundation/AppHost/AppControllerListener.h>

@interface LocalNotificationsPermissions : NSObject <AppControllerListener>
+ (void)request:(hivePermissionStatusHandler _Nonnull)callback;

@end
