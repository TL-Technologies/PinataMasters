//
//  Permissions.h
//  HiveFoundation
//
//  Created by Bartt on 17/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/Macro.h>
#import <HiveFoundation/Callbacks.h>


typedef NS_ENUM(int, HivePermissionCode)
{
    HivePermissionCode_None               = 0,
    HivePermissionCode_Gallery            = 1,
    HivePermissionCode_Camera             = 2,
    HivePermissionCode_LocalNotifications = 3,
};


typedef NS_ENUM(int, HivePermissionStatus)
{
    HivePermissionStatus_Unauthorized   = 0,
    HivePermissionStatus_Granted        = 1,
    HivePermissionStatus_Denied         = 2,
};

typedef void (^hivePermissionStatusHandler)(HivePermissionStatus status);

UNITY_EXPORT void hivePermissions_requestPermission(HivePermissionCode permissionCode, UnityInt32Callback callback);
