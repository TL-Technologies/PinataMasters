//
//  NSDictionary-Hive.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/Extensions/NSString-Hive.h>

@interface NSDictionary (Hive)
- (nullable NSString *)jsonString;
- (nullable UnityString)jsonUnityString;

@end


//------------------------------------------------------------------------------------
#pragma mark - Export C

// Serialize NSDictionary to a json string
FOUNDATION_EXPORT NSString* _Nullable hiveNSDictionaryToJsonNSString(NSDictionary* _Nullable dict);

// Serialize NSDictionary to a json Unity string
FOUNDATION_EXPORT UnityString _Nullable hiveNSDictionaryToJsonUnityString(NSDictionary* _Nullable dict);
