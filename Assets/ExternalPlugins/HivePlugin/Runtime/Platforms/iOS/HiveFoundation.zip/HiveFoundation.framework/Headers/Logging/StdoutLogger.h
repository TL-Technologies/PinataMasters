//
//  StdoutLogger.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HiveFoundation/Logging/Logger.h>

@interface StdoutLogger : NSObject <Logger>
@property (nonatomic) HiveLogLevelMask levelMask;

- (BOOL)isEnabled:(HiveLogLevel)level;

- (void)e:(nullable NSString *)format, ...;
- (void)w:(nullable NSString *)format, ...;
- (void)i:(nullable NSString *)format, ...;
- (void)d:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag e:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag w:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag i:(nullable NSString *)format, ...;
- (void)tag:(nullable NSString *)tag d:(nullable NSString *)format, ...;

@end
