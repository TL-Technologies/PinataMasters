//
//  AppHost.h
//  HiveFoundation
//
//  Created by Bartt on 28/05/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <HiveFoundation/Callbacks.h>
#import <HiveFoundation/Macro.h>
#import <HiveFoundation/AppHost/AppControllerDispatcher.h>
#import <HiveFoundation/Localization/LocalizedResources.h>
#import <HiveFoundation/Logging/Logger.h>

@interface AppHost : NSObject
@property (nonatomic, nonnull, strong, readonly) UIWindow* window;
@property (nonatomic, nonnull, strong, readonly) UIView* rootView;
@property (nonatomic, nonnull, strong, readonly) UIViewController* rootViewController;
@property (nonatomic, nonnull, strong, readonly) AppControllerDispatcher* appControllerDispatcher;
@property (nonatomic, nonnull, strong, readonly) NSBundle* bundle;
@property (nonatomic, nonnull, strong, readonly) LocalizedResources* localizedResources;
@property (nonatomic, readonly) BOOL isRunning;
@property (nonatomic, nonnull, readonly) id<Logger> logger;

+ (nonnull AppHost *)instance;

- (void)run;
- (void)dispatchToUnityThread:(nullable dispatch_block_t)block;
- (void)presentViewController:(nonnull UIViewController *)viewControllerToPresent
                     animated:(BOOL)flag
                   completion:(void (^ __nullable)(void))completion;

- (void)addAppControllerListener:(nonnull id<AppControllerListener>)listener;
- (void)removeAppControllerListener:(nonnull id<AppControllerListener>)listener;

- (void)invokeUnityCallback:(UnityVoidCallback)callback;
- (void)invokeUnityCallback:(UnityBooleanCallback)callback withBoolean:(BOOL)value;
- (void)invokeUnityCallback:(UnityInt32Callback)callback withInt32:(int)value;
- (void)invokeUnityCallback:(UnityStringCallback)callback withString:(nullable NSString *)value;
- (void)invokeUnityCallback:(UnityJsonCallback)callback withJson:(nullable NSDictionary *)value;

@end


//------------------------------------------------------------------------------------
#pragma mark - Unity Export

UNITY_EXPORT HiveLogLevelMask hiveAppHost_getLogLevelMask(void);
UNITY_EXPORT void hiveAppHost_setLogLevelMask(HiveLogLevelMask levelMask);
UNITY_EXPORT void hiveAppHost_run(void);
UNITY_EXPORT void hiveAppHost_setMemoryWarningHandler(UnityVoidCallback handler);
