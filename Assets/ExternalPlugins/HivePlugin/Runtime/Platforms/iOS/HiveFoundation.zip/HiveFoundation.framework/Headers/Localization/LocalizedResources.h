//
//  LocalizedResources.h
//  HiveFoundation
//
//  Created by Bartt on 14/06/2019.
//  Copyright © 2019 Hive Foundation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LocalizedResources : NSObject
@property (nonatomic, nonnull, strong, readonly) NSBundle* bundle;
@property (nonatomic, nonnull, strong, readonly) NSBundle* localizedBundle;
@property (nonatomic, nonnull, strong, readonly) NSString* table;

+ (nullable instancetype)resourcesWithBundle:(nonnull NSBundle *)bundle;
+ (nullable instancetype)resourcesWithBundle:(nonnull NSBundle *)bundle table:(nullable NSString *)table;

- (nullable instancetype)initWithBundle:(nonnull NSBundle *)bundle table:(nullable NSString *)table;
- (nullable instancetype)initWithBundle:(nonnull NSBundle *)bundle;

- (nonnull NSString *)localizedStringForKey:(nonnull NSString *)key;
- (nullable NSString *)pathForLocalizedResource:(nullable NSString *)nameAndExt;
- (nullable NSString *)pathForLocalizedResource:(nullable NSString *)name ofType:(nullable NSString *)ext;

@end
